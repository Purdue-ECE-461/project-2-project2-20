#include "mcm.h"


int main(int argc, char ** argv) {
    if (argc != 4) {
        return EXIT_FAILURE;
    }
    // argv[1]: input graph
    // argv[2]: minimum cycle mean file (binary)
    // argv[3]: minimum mean cycle

    //load graph
    Graph * graph = readInput(argv[1]);
    if (graph == NULL) {
        return EXIT_FAILURE;
    }

    //calculate MCM, find MMC (Karp's)
    int status = findMCM(graph, argv[2], argv[3]);

    if (status != 0) {
        freeGraph(graph);
        return EXIT_FAILURE;
    }

    freeGraph(graph);
    return EXIT_SUCCESS;
}