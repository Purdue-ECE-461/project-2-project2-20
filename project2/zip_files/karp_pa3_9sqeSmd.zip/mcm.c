#include "mcm.h"

Graph * readInput(char * filename) {
    FILE * fptr = fopen(filename, "r");
    if (fptr == NULL) {
        return NULL;
    }

    int num_vertex = -1;
    int num_edge = -1;
    fscanf(fptr, "V %d\nE %d\n", &num_vertex, &num_edge);

    if (num_vertex == -1 || num_edge == -1) {
        return NULL;
    }

    Graph * g = malloc(sizeof(Graph));

    Edge ** graph_edges = malloc(num_edge * sizeof(Edge*));

    double ** adj = malloc((num_vertex+1) * sizeof(double*));

    for (int i = 0; i <= num_vertex; i++) {
        adj[i] = malloc((num_vertex+1) * sizeof(double));
        for (int j = 0; j <= num_vertex; j++) {
            adj[i][j] = INFINITY;
        }
    }

    int start;
    int end;
    double weight;
    Edge * new_edge;
    for (int i = 0; i < num_edge; i++) {
        fscanf(fptr, "%d %d %lf\n", &end, &start, &weight);
        new_edge = malloc(sizeof(Edge));
        new_edge -> start = start;
        new_edge -> end = end;
        new_edge -> weight = weight;
        graph_edges[i] = new_edge;
        adj[start][end] = weight;
    }

    fclose(fptr);
    g -> connections = graph_edges;
    g -> num_vertex = num_vertex;
    g -> num_edge = num_edge;
    g -> matrix = adj;
    return g;
}

int findMCM(Graph * g, char * outfile1, char * outfile2) {
    int v = g->num_vertex;
    int e = g->num_edge;
    double ** distances = malloc((v+1) * sizeof(double*));
    int ** pred = malloc((v+1) * sizeof(int*));

    for (int i = 0; i <= v; i++) {
        distances[i] = malloc((v+1) * sizeof(double));
        pred[i] = malloc((v+1) * sizeof(int));
        for (int j = 0; j <= v; j++) {
            distances[i][j] = INFINITY;
            pred[i][j] = -1;
        }
    }
    distances[0][1] = 0;

    // Karp's Algorithm
    for (int edges = 1; edges <= v; edges++) {
        for (int ind = 0; ind < e; ind++) {
            Edge * cur = g->connections[ind];
            if (distances[edges][cur->end] > (distances[edges-1][cur->start] + cur->weight)) {
                distances[edges][cur->end] = distances[edges-1][cur->start] + cur->weight;
                pred[edges][cur->end] = cur->start;
            }
        }
    }
    double mcm = INFINITY;
    int mcm_ind;
    double lambda_v;
    for (int i = 1; i <= v; i++) {
        if (distances[v][i] == INFINITY) {
            continue;
        }
        lambda_v = -INFINITY;
        for (int k = 0; k < v; k++) {
            if (lambda_v < ((distances[v][i] - distances[k][i])/(v-k))) {
                lambda_v = (distances[v][i] - distances[k][i])/(v-k);
            }
        }
        if (lambda_v < mcm) {
            mcm = lambda_v;
            mcm_ind = i;
        }
    }

    // write MCM to file
    float mcm_to_write = (float) mcm;
    writeMCM(mcm_to_write, outfile1);

    // write MMC to file
    List * mmc = getMMC(pred, mcm_ind, v, g->matrix, mcm);
    if (mmc == NULL) {
        printf("ERROR\n");
        return -1;
    }
    FILE * fp2 = fopen(outfile2, "w");
    if (fp2 == NULL) {
        return -1;
    }
    for (int i = mmc->start; i < mmc->size; i++) {
        fprintf(fp2, "%d ", mmc->nums[i]);
    }
    fclose(fp2);

    //free everything
    free(mmc -> nums);
    free(mmc);
    for (int i = 0; i <= v; i++) {
        free(distances[i]);
        free(pred[i]);
    }
    free(distances);
    free(pred);
    return 0;
}

void writeMCM(float val, char * filename) {
    FILE * fp1 = fopen(filename, "wb");
    if (fp1 == NULL) {
        return;
    }
    fwrite(&val, sizeof(float), 1, fp1);
    fclose(fp1);
}

List * getMMC(int ** pred, int ind, int num_v, double ** edges, double mcm) {
    int num_elems = 0;
    int * cycle = malloc(num_elems * sizeof(int));
    int new_elem;
    int start_of_cycle = -1;

    new_elem = ind;
    num_elems = 1;
    cycle = realloc(cycle, num_elems * sizeof(int));
    cycle[num_elems-1] = new_elem;
    ind = pred[num_v][ind];


    for (int i = num_v-1; i > 0; i--) {
        new_elem = ind;
        for (int j = 0; j < num_elems; j++) { // check if new element is in cycle
            if (new_elem == cycle[j] && isMMC(cycle, j, num_elems, edges, mcm)) {
                start_of_cycle = j;
                break;
            }
        }
        if (start_of_cycle > -1) { 
            break;
        }
        num_elems++;
        cycle = realloc(cycle, num_elems * sizeof(int));
        cycle[num_elems-1] = new_elem;
        ind = pred[i][ind];
    }

    if (start_of_cycle == -1) {
        return NULL;
    }

    List * mmc = malloc(sizeof(List));
    mmc -> nums = cycle;
    mmc -> size = num_elems;
    mmc -> start = start_of_cycle;
    return mmc;
}

bool isMMC(int * vertices, int start, int num_v, double ** matrix, double mcm) {
    double cycle_weight = -1 * (num_v - start) * mcm;
    double current_edge;

    current_edge = matrix[vertices[start]][vertices[num_v-1]];
    cycle_weight += current_edge;
    for (int i = start+1; i < num_v; i++) {
        // get edge weight to current element
        current_edge = matrix[vertices[i]][vertices[i-1]];
        cycle_weight += current_edge;
    }

    return fabs(cycle_weight) < 1e-6;
}

void freeGraph(Graph * g) {
    for (int i = 0; i < g->num_edge; i++) {
        free(g->connections[i]);
    }
    for (int i = 0; i <= g-> num_vertex; i++) {
        free(g->matrix[i]);
    }
    free(g->connections);
    free(g->matrix);
    free(g);
}

void printMatrix(Graph * g) {
    printf("MATRIX:\n");
    for (int i = 0; i <= g->num_vertex; i++) {
        for (int j = 1; j <= g->num_vertex; j++) {
            printf("%4.1lf ", g->matrix[i][j]);
        }
        printf("\n");
    }
}

void printStuff(double ** distances, int ** pred, int v) {
    //print distances
    printf("DISTANCES:\n");
    for (int i = 0; i <= v; i++) {
        for (int j = 1; j <= v; j++) {
            printf("%5.2lf ", distances[i][j]);
        }
        printf("\n");
    }

    //print pred
    printf("PRED:\n");
    for (int i = 0; i <= v; i++) {
        for (int j = 1; j <= v; j++) {
            printf("%2d ", pred[i][j]);
        }
        printf("\n");
    }
}