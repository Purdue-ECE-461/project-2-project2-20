#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <float.h>

typedef struct _Edge {
    int start;
    int end;
    double weight;
} Edge;

typedef struct _Graph {
    Edge ** connections;
    int num_vertex;
    int num_edge;
    double ** matrix;
} Graph;

typedef struct _List {
    int * nums;
    int size;
    int start;
} List;

Graph * readInput(char * filename);

int findMCM(Graph * g, char * outfile1, char * outfile2);

void writeMCM(float val, char * filename);

List * getMMC(int ** pred, int ind, int num_v, double ** edges, double mcm);

bool isMMC(int * vertices, int start, int num_v, double ** matrix, double mcm);

void freeGraph(Graph * g);

void printMatrix(Graph * g);

void printStuff(double ** distances, int ** pred, int v);