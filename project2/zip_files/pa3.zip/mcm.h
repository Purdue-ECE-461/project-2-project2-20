#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <float.h>

typedef struct _Edge {
    int start;
    int end;
    double weight;
} Edge;

typedef struct _Graph {
    Edge ** connections;
    int num_vertex;
    int num_edge;
    double ** matrix;
} Graph;

typedef struct _List {
    int * nums;
    int size;
    int start;
} List;

Graph * readInput(char * filename);

int findMCM(Graph * g, char * outfile1, char * outfile2);

void writeMCM(float val, char * filename);

List * getMMC(int ** pred, int ind, int row_num, double ** edges, double mcm);

double * computeLambda(int row_num, double ** distances);

double * getPiArray(int row_num, int num_vertex, double lambda_k, double ** distances);

bool checkET(double * pi, double lambda_k, Edge ** edges, int num_edge);

bool isLogTwo(int x);

bool isMMC(int * vertices, int start, int num_v, double ** matrix, double mcm);

void writeMMC(char * filename, List * mmc);

void freeGraph(Graph * g);

void printMatrix(Graph * g);

void printStuff(double ** distances, int ** pred, int v);