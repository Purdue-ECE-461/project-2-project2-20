#include "mcm.h"

Graph * readInput(char * filename) {
    FILE * fptr = fopen(filename, "r");
    if (fptr == NULL) {
        return NULL;
    }

    int num_vertex = -1;
    int num_edge = -1;
    fscanf(fptr, "V %d\nE %d\n", &num_vertex, &num_edge);

    if (num_vertex == -1 || num_edge == -1) {
        return NULL;
    }

    Graph * g = malloc(sizeof(Graph));

    Edge ** graph_edges = malloc(num_edge * sizeof(Edge*));

    double ** adj = malloc((num_vertex+1) * sizeof(double*));

    for (int i = 0; i <= num_vertex; i++) {
        adj[i] = malloc((num_vertex+1) * sizeof(double));
        for (int j = 0; j <= num_vertex; j++) {
            adj[i][j] = INFINITY;
        }
    }

    int start;
    int end;
    double weight;
    Edge * new_edge;
    for (int i = 0; i < num_edge; i++) {
        fscanf(fptr, "%d %d %lf\n", &end, &start, &weight);
        new_edge = malloc(sizeof(Edge));
        new_edge -> start = start;
        new_edge -> end = end;
        new_edge -> weight = weight;
        graph_edges[i] = new_edge;
        adj[start][end] = weight;
    }

    fclose(fptr);
    g -> connections = graph_edges;
    g -> num_vertex = num_vertex;
    g -> num_edge = num_edge;
    g -> matrix = adj;
    return g;
}

int findMCM(Graph * g, char * outfile1, char * outfile2) {
    int v = g->num_vertex;
    int e = g->num_edge;
    double ** distances = malloc((v+1) * sizeof(double*));
    int ** pred = malloc((v+1) * sizeof(int*));
    int termination = v;
    double mcm;
    int mcm_ind;
    List * mmc;

    for (int i = 0; i <= v; i++) {
        distances[i] = malloc((v+1) * sizeof(double));
        pred[i] = malloc((v+1) * sizeof(int));
        for (int j = 0; j <= v; j++) {
            distances[i][j] = INFINITY;
            pred[i][j] = -1;
        }
    }
    distances[0][1] = 0;

    // Karp's Algorithm
    for (int edges = 1; edges <= v; edges++) {
        for (int ind = 0; ind < e; ind++) {
            Edge * cur = g->connections[ind];
            if (distances[edges][cur->end] > (distances[edges-1][cur->start] + cur->weight)) {
                distances[edges][cur->end] = distances[edges-1][cur->start] + cur->weight;
                pred[edges][cur->end] = cur->start;
            }
        }
        if (isLogTwo(edges)) { // check for early termination
            //compute lambda_k
            double * lambda_and_index = computeLambda(edges, distances);
            /* lambda_and_index[0] = lambda_k
               lambda_and_index[1] = index in last row corresponding to lambda_k */
            if (isinf(lambda_and_index[0])) { // no mcm found
                free(lambda_and_index);
                continue;
            }
            //compute pi_v
            double * pi_array = getPiArray(edges, v, lambda_and_index[0], distances);

            //check inequality
            bool foundMinCycle = checkET(pi_array, lambda_and_index[0], g->connections, e);
            if (foundMinCycle) {
                mmc = getMMC(pred, lambda_and_index[1], edges, g->matrix, lambda_and_index[0]);
                if (mmc -> start > -1) {
                    termination = edges;
                }
                free(mmc -> nums);
                free(mmc);
            }

            //free stuff
            free(lambda_and_index);
            free(pi_array);

            if (termination < v) {
                break;
            }
        }
    }
    double * mcm_and_index = computeLambda(termination, distances);

    mcm = mcm_and_index[0];
    mcm_ind = (int) mcm_and_index[1];
    free(mcm_and_index);

    // write MCM to file
    float mcm_to_write = (float) mcm;
    writeMCM(mcm_to_write, outfile1);

    // write MMC to file
    mmc = getMMC(pred, mcm_ind, termination, g->matrix, mcm);
    if (mmc == NULL) {
        return -1;
    }
    writeMMC(outfile2, mmc);

    //free everything
    free(mmc -> nums);
    free(mmc);
    for (int i = 0; i <= v; i++) {
        free(distances[i]);
        free(pred[i]);
    }
    free(distances);
    free(pred);
    return 0;
}

double * computeLambda(int row_num, double ** distances) {
    double mcm = INFINITY;
    int mcm_ind;
    double lambda;
    for (int i = 1; i <= row_num; i++) {
        if (distances[row_num][i] == INFINITY) {
            continue;
        }
        lambda = -INFINITY;
        for (int k = 0; k < row_num; k++) {
            if (lambda < ((distances[row_num][i] - distances[k][i])/(row_num-k))) {
                lambda = ((distances[row_num][i] - distances[k][i])/(row_num-k));
            }
        }
        if (lambda < mcm && lambda != -INFINITY) {
            mcm = lambda;
            mcm_ind = i;
        }
    }
    double * vals = malloc(2 * sizeof(double));
    vals[0] = mcm;
    vals[1] = mcm_ind;

    return vals;
}

double * getPiArray(int row_num, int num_vertex, double lambda_k, double ** distances) {
    double * pi_array = malloc((num_vertex + 1) * sizeof(double));
    for (int i = 0; i <= num_vertex; i++) {
        pi_array[i] = INFINITY;
    }

    double cur;

    for (int v_num = 1; v_num <= num_vertex; v_num++) {
        for (int edge_num = 0; edge_num <= row_num; edge_num++) {
            cur = (distances[edge_num][v_num] - (edge_num * lambda_k));
            if (cur < pi_array[v_num]) {
                pi_array[v_num] = cur;
            }
        }
    }

    return pi_array;
}

bool checkET(double * pi, double lambda_k, Edge ** edges, int num_edge) {
    int cur_u;
    int cur_v;
    double cur_weight;
    double cur_pi_v;
    double cur_pi_u;

    for (int i = 0; i < num_edge; i++) {
        cur_u = edges[i] -> start;
        cur_v = edges[i] -> end;
        cur_weight = edges[i] -> weight;

        cur_pi_v = pi[cur_v];
        cur_pi_u = pi[cur_u];

        double compare_val = cur_pi_u + cur_weight - lambda_k + 1e-10;

        if (cur_pi_v > compare_val) {
            return false;
        }
    }

    return true;
}

bool isLogTwo(int x) {
    int pow = 2;
    while (pow < x) {
        pow *= 2;
    }

    return (pow == x);
}

void writeMCM(float val, char * filename) {
    FILE * fp1 = fopen(filename, "wb");
    if (fp1 == NULL) {
        return;
    }
    fwrite(&val, sizeof(float), 1, fp1);
    fclose(fp1);
}

List * getMMC(int ** pred, int ind, int row_num, double ** edges, double mcm) {
    int num_elems = 0;
    int * cycle = malloc(num_elems * sizeof(int));
    int new_elem;
    int start_of_cycle = -1;

    new_elem = ind;
    num_elems = 1;
    cycle = realloc(cycle, num_elems * sizeof(int));
    cycle[num_elems-1] = new_elem;
    ind = pred[row_num][ind];


    for (int i = row_num-1; i > 0; i--) {
        new_elem = ind;
        for (int j = 0; j < num_elems; j++) { // check if new element is in cycle
            if (new_elem == cycle[j] && isMMC(cycle, j, num_elems, edges, mcm)) {
                start_of_cycle = j;
                break;
            }
        }
        if (start_of_cycle > -1) { 
            break;
        }
        num_elems++;
        cycle = realloc(cycle, num_elems * sizeof(int));
        cycle[num_elems-1] = new_elem;
        ind = pred[i][ind];
    }

    List * mmc = malloc(sizeof(List));
    mmc -> nums = cycle;
    mmc -> size = num_elems;
    mmc -> start = start_of_cycle;
    return mmc;
}

bool isMMC(int * vertices, int start, int num_v, double ** matrix, double mcm) {
    double cycle_weight = -1 * (num_v - start) * mcm;
    double current_edge;

    current_edge = matrix[vertices[start]][vertices[num_v-1]];
    cycle_weight += current_edge;
    for (int i = (start+1); i < num_v; i++) {
        // get edge weight to current element
        current_edge = matrix[vertices[i]][vertices[i-1]];
        cycle_weight += current_edge;
    }

    return fabs(cycle_weight) < 1e-6;
}

void writeMMC(char * filename, List * mmc) {
    FILE * fp2 = fopen(filename, "w");
    if (fp2 == NULL) {
        return;
    }
    for (int i = mmc->start; i < mmc->size; i++) {
        fprintf(fp2, "%d ", mmc->nums[i]);
    }
    fclose(fp2);
    return;
}

void freeGraph(Graph * g) {
    for (int i = 0; i < g->num_edge; i++) {
        free(g->connections[i]);
    }
    for (int i = 0; i <= g-> num_vertex; i++) {
        free(g->matrix[i]);
    }
    free(g->connections);
    free(g->matrix);
    free(g);
}

void printMatrix(Graph * g) {
    printf("MATRIX:\n");
    for (int i = 0; i <= g->num_vertex; i++) {
        for (int j = 1; j <= g->num_vertex; j++) {
            printf("%4.1lf ", g->matrix[i][j]);
        }
        printf("\n");
    }
}

void printStuff(double ** distances, int ** pred, int v) {
    //print distances
    printf("DISTANCES:\n");
    for (int i = 0; i <= v; i++) {
        for (int j = 1; j <= v; j++) {
            printf("%5.2lf ", distances[i][j]);
        }
        printf("\n");
    }

    //print pred
    printf("PRED:\n");
    for (int i = 0; i <= v; i++) {
        for (int j = 1; j <= v; j++) {
            printf("%2d ", pred[i][j]);
        }
        printf("\n");
    }
}